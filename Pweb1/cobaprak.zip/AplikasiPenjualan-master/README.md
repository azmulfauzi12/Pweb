# AplikasiPenjualan
Source Code Aplikasi Penjualan Sederhana

# Tutorial Build with Android Studio
https://youtu.be/x8i8qWcrJKY

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2019/04/tutorial-membuat-aplikasi-penjualan.html
